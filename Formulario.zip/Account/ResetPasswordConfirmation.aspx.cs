﻿using System.Web.UI;

namespace Formulario.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}